# lython

A minimal package seeking to combine LLM agent with the simplicity python syntax. 

### Usage

- Dependency
  - langfuse for observability
  - python3.12 for development

to try the project, start backend and frontend, then open http://localhost:18501

  - Deploy Langfuse and modify `server.py` to point to deployment
  - Start backend with `uvicorn lython.server:app  --port=18000` to start the backend websocket server
  - `cd chatbot-ui; npm run dev` to start a dev frontend to see agent running
    - `chatbot-ui/.env` to set backend url


### Files Description

- lython/
  - agent_interface.py : Shared tools made available by injecting into agent prompt
  - agent_notebook_checker.py : An example agent to analyse failed jupyter notebook
  - agent_proto.py: Shared agent logic to create a LLM-based sampler from a while loop.
  - embed_code_runtime.py: unsafe python executor that requires human supervision
  - safe_code_runtime.py: A human reviewed python executor with risky functions removed
  - server.py : For starting the demo backend

### Changelog
- v004: Implement explicit history management with `workflow.append_msg_tuple(role:str, msg:str, history:list[tuple]) -> list[tuple]` 


### Useful ref:
- https://artificialanalysis.ai/models/qwen2-5-coder-32b-instruct