'''
All objects in this module needs to be SafeObject or SafeFunc!!!!
'''
import os
import io
def possible_errors(errors):
    def dec(f):
        return f
    return dec
    
class SafeObject(object):
    '''
    Safe Object follows 2 criteria
      1. if introducing file operation, needs to be read-only
      2. if introducing web operation, needs to be a read-only web op
      3. should not contain dynamic code
    '''
    safe = True
    
class SendContentTooLong(Exception):
    """This means the file you are trying to read is too long"""
    filename:str
    
class AgentInterface(SafeObject):
    safe = True
    workflow = None
    
    buffer = io.StringIO()
    
    buffer_max_char = 3000
    send_max_char = 2000
    @classmethod
    def get_safe_buffer(self):
        self.buffer.seek(0)
        text = self.buffer.read()
        buffer_len = len(text)

        if (buffer_len) > self.buffer_max_char:
            text = text[:self.buffer_max_char]
            text = text + '\n' + str(SendContentTooLong(f'Exceeding max_char={self.buffer_max_char}. Trying to send {buffer_len} chars'))
            # raise SendContentTooLong(f'Exceeding max_char={self.buffer_max_char}. Trying to send {buffer_len} chars')
        assert buffer_len,"Buffer is empty, Did you forget to call AgentInterface.send()?"
        return text
    
    @classmethod
    def send(self, content:str):
        """Send output to you! You wont see result unless _send_to_agent()
        Do not send suggestion or code-to-execute through this interface. 
        """ 
        # print(self.content)
        if len(content) > self.send_max_char:
            content = content[:self.send_max_char]
            content = content + '\n' +  str(SendContentTooLong(f'Exceeding max_char={self.send_max_char}. Trying to send {content} chars'))
            # raise SendContentTooLong(f'Exceeding max_char={self.send_max_char}. Trying to send {len(content)} chars')
        self.buffer.write(content)
        self.buffer.write('\n')
        return 
    
                
    class File(object):           
        content: str

        @classmethod
        def open_local(cls, filename:str,mode, *a, **kw) -> 'File':      
            """Read a local file"""
            assert mode in ['r','rb']
            return open(filename,*a,mode=mode, **kw)

        agent_dir = '/tmp/lython_agent_001/'
        os.makedirs(agent_dir,exist_ok=True)

        @classmethod
        def write_local(cls, filename:str, content:str, mode:str,encoding:str) -> 'File':      
            """Write the content to a local file"""
            filename = os.path.realpath(filename)
            if filename.startswith(cls.agent_dir):
                with open(filename, mode=mode, encoding=encoding) as f:
                    f.write(content)
                    return
            else:
                raise RuntimeError(f'You are not allowed to modify local file outside {cls.agent_dir!r}')
        
        def learn_func(func_name:str):
            """Learn more information about a function"""            


# Test the function
# AgentInterface.extract_exception_traceback('./temp.ipynb')