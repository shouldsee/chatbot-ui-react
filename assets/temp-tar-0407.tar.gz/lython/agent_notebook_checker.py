import os,sys
import subprocess
from bs4 import BeautifulSoup
import time
import functools
from pprint import pformat
import tempfile

import json
from pprint import pprint

from pydantic import Field
from pydantic import BaseModel

from .agent_interface import AgentInterface
from .safe_code_runtime import SafeCodeRuntime

import copy 

from .agent_proto import wrap_xml_tag
from .agent_proto import AgentPrototype
from .agent_proto import LLMXMLBaseModel
from .agent_proto import LLMJsonBaseModel

        
class SysActionBase(object):
    pass

class SysActionExit(SysActionBase):
    pass
class SysActionLoop(SysActionBase):
    pass

class SysActionState(SysActionBase):
    def __init__(self,state):
        self.state = state
    pass

class agent_message_cls(LLMXMLBaseModel,):
    '''
    Make sure agent only do simple generation
    1. thought
    2. code
    3. classifier
    
    '''
    thought:str=Field(default='',
                        description='describe your thinking process')
    code:str=Field(default='',
                    description='python code attached to this message.')
    agent_summary:str=Field(default='',
                                    description='A short sentence describing intention of this message ')        
    state:str='[TBC]' ### please specify
    
    _keep_result_only = 0
        
    @staticmethod
    def action(message, workflow, history):
        ''' run action contained in its code'''
        print('CodeToRun!!!\n'+message.code)
        
        workflow.last_resp = None
        code = '\n'.join([
            message.code ,
            'AgentInterface.get_safe_buffer()',
        ])

        history, new_msg = workflow.exec_and_send( code, history, message._keep_result_only)

        return history
        
    def to_msg_storage_str(self):
        tag = self.get_raw_msg_tag()
        tag = copy.deepcopy(tag)
        if not int(self._keep_result_only):
            [getattr(x,'decompose', lambda : None)() for x in tag.select('code')]
        return tag.decode_contents() 


    def run_loop(this_agent_message, workflow, history):
        self = workflow
        sys_action = SysActionLoop()
        agent_message = this_agent_message ### init as a cls

        while True:
            if isinstance(sys_action, SysActionExit):
                return history    
            elif isinstance(sys_action, SysActionLoop):            

                ### reset last_resp                
                agent_message, history = self.on_sample_action(this_agent_message, history)
                agent_next_method = getattr(agent_message,'on_'+self.state, None)
                if agent_next_method is not None:
                    sys_action, history = agent_next_method(agent_message, self, history)
                else:                
                    _ = self.append_msg_tuple('sys_to_user',
                        f'Got unknown state {self.state!r}. Please check whether you validate the msg state', history)

                    history = self.append_msg_tuple('sys_to_agent',
                            f'Note your output should stick to this format {this_agent_message.to_xml_prompt()}',
                            history)
                    sys_action = SysActionLoop()
                    
            elif isinstance(sys_action, SysActionState):            
                self.state = sys_action.state
                agent_next_method = getattr(agent_message,'on_'+self.state, None)
                sys_action, history = agent_next_method(agent_message, self, history)

            else:
                raise RuntimeError(f'Unknown Action {sys_action!r}')        
            assert isinstance(sys_action,SysActionBase),sys_action.__repr__()
            continue


class AgentNotebookChecker(AgentPrototype):

    def __init__(self,*a,filename=None, **kw):
        super().__init__(*a,**kw)
        self.filename = filename
        self.kwargs = dict(filename=filename)
        def _check_target(**kwargs):
            import json      
            fn = kwargs['filename']          
            with AgentInterface.File.open_local(fn,'r') as f:
                ret = json.loads(f.read())      
                done = ret['metadata']['papermill']['exception'] is None
                assert done
        self._check_target = _check_target
    
    # code_runtime = EmbedCodeRuntime() ## <-- non-safe runtime
    code_runtime = SafeCodeRuntime()    ## <-- safe for auto-running
    tool_cls     = AgentInterface # <- agent prompt would contain sourcefile of this class and try to use functions within it        
    

    def get_target_text(self):
        target_desp = f'''
            - Find the root cause of the ipynb notebook failure detected by _check_target()
            - Propose suitable solution to improve the system to address the root cause
            - Please try running _check_target() and see why it failed.
            - You should not modify _check_target()
            - The root cause should explain why the _check_target() failed. 
                <code>
                {self.get_checker_code()}
                </code>
            - You should analyse the relevant file to find out the root cause of an error. 
            - You should not change the value of "ret['metadata']['papermill']['exception']". It is a result of required program execution.
        '''.strip()
        return target_desp
    
    
    print_channels = ['user',
                      'assistant_final',
                      'sys_summary',
                      'error',

                      'assistant',
                      'sys_to_agent','agent_interface'

                      ]

    ### 1 million $5 for gpt-4o
    ### 1 million $0.5 for gpt-4o-mini
    ### 20k*50 = 1million, cap at $0.5
    # self.max_context_length = 20*1000

    ### qwen model becomes broken after 25k tokens
    # self.max_context_length = 25*1000
 
    max_context_length = 35*1000
    def run(self,):
        '''
        Break into two sub functions for easier logging with langfuse
        '''
        history = tuple()
        self.state = 'INIT'
        history = self.init_loop(history)
        history = self.run_loop(history)
        return history
        

    class agent_loop_try(agent_message_cls):
        state:str=Field(default='',
                        description=f'''
        # use state=RUN to run code 
        # use state=CODE_FIX to propose code fix
        - exclude {AgentInterface.__class__.__name__} in code when in this state
        # DO NOT use other state unless instructed to do so
                            '''.strip())            
        @staticmethod
        def on_CODE_FIX(agent_message, workflow, history):
            history = workflow.append_msg_tuple('assistant_final', agent_message.get_raw_msg_tag().decode_contents(), history)
            return SysActionState('SELF_EVAL'), history

        @staticmethod
        def on_SELF_EVAL(agent_message, workflow, history):
            history = workflow.append_msg_tuple('assistant_final', agent_message.get_raw_msg_tag().decode_contents(), history)
            return SysActionExit(), history

        @staticmethod
        def on_RUN(agent_message, workflow, history):

            if agent_message.code=='':
                history = workflow.append_output_format_msg(history)
                history = workflow.append_msg_tuple('sys_to_agent',wrap_xml_tag("SystemError","Please make sure <code> tag is not empty!!!!"), history)
                return SysActionLoop(), history
            history = agent_message.action(agent_message, workflow, history)

            return SysActionLoop(), history                  



    def run_loop(self, history):
        while True:
            history             = self.search_tools(history)
            ### this is for tracing only
            _ = self.append_msg_tuple('sys_trace', self.prompt_getter(self.agent_loop_try), history)
            history = self.agent_loop_try.run_loop(workflow, history)
            # history             = self.on_try_target(history)   ### ask agent to attempt a solution
            history,eval_state  = self.on_self_eval(history)    ### ask agent to evaluate a solution
            if eval_state == 'DONE':
                break
            elif eval_state =='RETRY':
                continue
        history = self.on_summary_solution(history)              ### ask agent to summarize the solution
        return history
    
    def init_loop(self, history):
        ret = self.get_user_input('Initing...')
        while True:
            ret = self.get_user_input('[AgentStateDone]Please choose whether to : (nEXT/cLEAR)').strip()
            if ret == 'n':
                break
            elif ret == 'c':
                history = tuple()
                continue
            print(f'[GotUserReply]{ret!r}')        
            history = self.append_msg_tuple('user', ret, history)

        self.t0 = time.time()
        self.state = 'INIT'
        if self.state =='INIT':
            ### init blocker
            ret = self.get_user_input('Press any key to start')
            history = self.append_msg_tuple('user',self.prompt_getter(),history)
            history, new_msg = self.check_target(history)        

            ret = self.get_user_input(f'Press any key to start. Will print following channels. {self.print_channels}')    
        return history       

    def on_self_eval(self, history):
        '''
        Ask agent to evaluate the code fix
        '''
        # json.dumps(agent_message.dict(),indent=2))
        while True:
            prompt =  \
            "\nSet <state>...</state> to TRUE/FALSE/UNABLE depending on your answer."
            "\n TRUE:  if the provided code fix the issue in original notebook code."
            "\n RUN: there is no code, but possible to investigate further for a code fix"
            "\n UNABLE: if the fix need to be done outside this notebook. Please explain your choice."
            
            history = self.append_msg_tuple('sys_to_agent', prompt, history)
            ### sample another message from agent
            agent_message, history = self.on_sample_action(self.output_cls, history)
            history = self.append_msg_tuple('assistant_final',agent_message.get_raw_msg_tag().decode_contents(), history)
            
            if self.state in 'TRUE UNABLE'.split():                    
                history = self.append_msg_tuple('user',"DONE",history)
                return history, "DONE"

            elif self.state=='RUN':
                # self.state = 'RUN'
                history = self.append_msg_tuple('user',f"Your state is reset to {self.state}", history)
                history = self.append_msg_tuple('user',"Please continue analyse to get a code fix.", history)
                return history, "RETRY"
            else:
                history = self.append_msg_tuple('sys_to_agent',ValueError(f'Unexpected state,{self.state}'), history)
                continue 
            
    def on_summary_solution(self, history):
        history = self.append_msg_tuple('sys_to_agent',
        "Given the conversation history above, and extra info below"
        f"\n The original target was <target>{self.get_target_text()}</target>"
        "\n please do the following"
        "\n Identify whether the target completion could be faster"
        "\n If yes, please also identify why it is taking multiple rounds to reach the target."
        "\n   Then propose how you could solve this problem faster next time. "
        "\n   Then propose what code you could use to solve this problem faster next time. "
        "\n"
        "\n You should use this format below"
        "\n <thought>... Your thinking behind inventing this tool </thought>"
        "\n <could_faster>... </could_faster>  ## set YES if could be faster, NO if already fast enough"
        "\n <state>... </state>  ## set PASS to indicate test passed, or TESTING for running test"
        "\n <intent>... when this tool should be applied </intent>"
        "\n <code>... The actual python code functions to be added to AgentInterface.xxx(). This should also include a function to test the function</code>"
        ,history)
        while True:
            agent_message, history = self.on_sample_action(self.output_cls, history)
            history = self.append_msg_tuple('assistant_final',agent_message.get_raw_msg_tag().decode_contents(),history)
            if self.state == 'PASS':
                history = self.append_msg_tuple('assistant_final',"TESTING PASSED", history)
                # agent_message.get_raw_msg_tag().decode_contents(),add_to_history=False)  
                return history
            elif self.state == 'GOOG':
                history = self.append_msg_tuple('assistant_final',"GOOD", history)
                return history
            else:
                history = agent_message.action(agent_message, self, history)



        
             
    output_cls = agent_message_cls
    output_cls_name = output_cls.__name__




            


    def search_tools(self, history):
        '''Placeholder to add tool searching'''
        return history
    

    ### agent-proposed tool for AgentInterface
    @classmethod
    def extract_exception_traceback(cls, filename: str):
        import json
        """Extract and send the exception traceback from the notebook cells."""
        with cls.File.open_local(filename, 'r') as f:
            content = json.load(f)
            cells = content['cells']
            for i, cell in enumerate(cells):
                if 'outputs' in cell:
                    for output in cell['outputs']:
                        if 'ename' in output or 'evalue' in output or 'traceback' in output:
                            cls.send(f"Cell {i} caused an exception:")
                            cls.send(f"ename: {output.get('ename', 'N/A')}")
                            cls.send(f"evalue: {output.get('evalue', 'N/A')}")
                            cls.send(f"traceback: {output.get('traceback', 'N/A')}")
                            break

    ### agent-proposed tool for AgentInterface
    # @classmethod
    # def extract_exception_traceback(cls, filename: str):
    #     """Extract exception traceback from notebook cells"""
    #     with cls.File.open_local(filename, 'r') as f:
    #         notebook_content = f.read()
    #         notebook_json = json.loads(notebook_content)
    #         cells = notebook_json['cells']
    #         for cell in cells:
    #             if 'outputs' in cell:
    #                 for output in cell['outputs']:
    #                     if 'ename' in output or 'evalue' in output or 'traceback' in output:
    #                         cls.send(f"Error in cell: {cell['source']}")
    #                         cls.send(f"Error name: {output.get('ename', 'N/A')}")
    #                         cls.send(f"Error value: {output.get('evalue', 'N/A')}")
    #                         cls.send(f"Traceback: {output.get('traceback', 'N/A')}")
    #                         return True
    #     return False

if __name__ == '__main__':
    workflow = AgentNotebookChecker('./temp.ipynb', tool_cls_list=[AgentInterface])
    workflow.run()
