from .agent_interface import *
from .proto_code_runtime import ProtoCodeRuntime
import uuid
import json
import multiprocessing
import threading
import linecache
class EmbedCodeRuntime(object):
    is_safe = False ### this runtime is of high code risk  !!!!
    result_by_id = {}

    def on_exec_code(self, code, req_id):
                        
        stdout = ''
        success = 0
        exc_str = ''

        def better_compile(src, name, mode):
            # there is an example of this being set at
            # https://hg.python.org/cpython/file/2.7/Lib/linecache.py#l104
            linecache.cache[name] = (
                len(src), None,
                [line+'\n' for line in src.splitlines()], name
            )
            return compile(src, name, mode)                
        try:
            code_obj = better_compile(code, '<agent-code>', 'exec')    
            _ = exec(code_obj)
            stdout = repr(stdout)
        except Exception as e:
            import traceback; 
            exc_str = traceback.format_exc()
        
        exec_result_content = f'''
<CodeExecResult>

<code>
{code}
</code>

<exception>
{exc_str}
</exception>

</CodeExecResult>
        '''.strip()
        return exec_result_content, success