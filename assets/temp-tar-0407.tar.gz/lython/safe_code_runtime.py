from .agent_interface import AgentInterface
from .agent_interface import SafeObject
from .proto_code_runtime import ProtoCodeRuntime
import linecache
class NotAllowedError(Exception):
    '''
    Functions that are prohibited for agent.
    '''
    pass

BUILTIN_WHITELIST = \
['__name__',
 '__doc__',
 '__package__',
#  '__loader__',
 '__spec__',
 '__build_class__',
 'breakpoint',
#  '__import__',
 'abs',
 'all',
 'any',
 'ascii',
 'bin',
#  'breakpoint',
 'callable',
 'chr',
#  'compile',
 'delattr',
 'dir',
 'divmod',
#  'eval',
#  'exec',
 'format',
 'getattr',
#  'globals',
 'hasattr',
 'hash',
 'hex',
 'id',
#  'input',
 'isinstance',
 'issubclass',
 'iter',
 'aiter',
 'len',
#  'locals',
 'max',
 'min',
 'next',
 'anext',
 'oct',
 'ord',
 'pow',
 'print',
 'repr',
 'round',
 'setattr',
 'sorted',
 'sum',
 'vars',
 'None',
 'Ellipsis',
 'NotImplemented',
 'False',
 'True',
 'bool',
 'memoryview',
 'bytearray',
 'bytes',
 'classmethod',
 'complex',
 'dict',
 'enumerate',
 'filter',
 'float',
 'frozenset',
 'property',
 'int',
 'list',
 'map',
 'object',
 'range',
 'reversed',
 'set',
 'slice',
 'staticmethod',
 'str',
 'super',
 'tuple',
 'type',
 'zip',
 '__debug__',
 'BaseException',
 'BaseExceptionGroup',
 'Exception',
 'GeneratorExit',
 'KeyboardInterrupt',
 'SystemExit',
 'ArithmeticError',
 'AssertionError',
 'AttributeError',
 'BufferError',
 'EOFError',
 'ImportError',
 'LookupError',
 'MemoryError',
 'NameError',
 'OSError',
 'ReferenceError',
 'RuntimeError',
 'StopAsyncIteration',
 'StopIteration',
 'SyntaxError',
 'SystemError',
 'TypeError',
 'ValueError',
 'Warning',
 'FloatingPointError',
 'OverflowError',
 'ZeroDivisionError',
 'BytesWarning',
 'DeprecationWarning',
 'EncodingWarning',
 'FutureWarning',
 'ImportWarning',
 'PendingDeprecationWarning',
 'ResourceWarning',
 'RuntimeWarning',
 'SyntaxWarning',
 'UnicodeWarning',
 'UserWarning',
 'BlockingIOError',
 'ChildProcessError',
 'ConnectionError',
 'FileExistsError',
 'FileNotFoundError',
 'InterruptedError',
 'IsADirectoryError',
 'NotADirectoryError',
 'PermissionError',
 'ProcessLookupError',
 'TimeoutError',
 'IndentationError',
 'IndexError',
 'KeyError',
 'ModuleNotFoundError',
 'NotImplementedError',
 'RecursionError',
 'UnboundLocalError',
 'UnicodeError',
 'BrokenPipeError',
 'ConnectionAbortedError',
 'ConnectionRefusedError',
 'ConnectionResetError',
 'TabError',
 'UnicodeDecodeError',
 'UnicodeEncodeError',
 'UnicodeTranslateError',
 'ExceptionGroup',
 'EnvironmentError',
 'IOError',
#  'open',
#  'quit',
#  'exit',
 'copyright',
 'credits',
 'license',
 'help']

BUILTIN_ALL = \
['__name__',
 '__doc__',
 '__package__',
 '__loader__',
 '__spec__',
 '__build_class__',
 '__import__',
 'abs',
 'all',
 'any',
 'ascii',
 'bin',
 'breakpoint',
 'callable',
 'chr',
 'compile',
 'delattr',
 'dir',
 'divmod',
 'eval',
 'exec',
 'format',
 'getattr',
 'globals',
 'hasattr',
 'hash',
 'hex',
 'id',
 'input',
 'isinstance',
 'issubclass',
 'iter',
 'aiter',
 'len',
 'locals',
 'max',
 'min',
 'next',
 'anext',
 'oct',
 'ord',
 'pow',
 'print',
 'repr',
 'round',
 'setattr',
 'sorted',
 'sum',
 'vars',
 'None',
 'Ellipsis',
 'NotImplemented',
 'False',
 'True',
 'bool',
 'memoryview',
 'bytearray',
 'bytes',
 'classmethod',
 'complex',
 'dict',
 'enumerate',
 'filter',
 'float',
 'frozenset',
 'property',
 'int',
 'list',
 'map',
 'object',
 'range',
 'reversed',
 'set',
 'slice',
 'staticmethod',
 'str',
 'super',
 'tuple',
 'type',
 'zip',
 '__debug__',
 'BaseException',
 'BaseExceptionGroup',
 'Exception',
 'GeneratorExit',
 'KeyboardInterrupt',
 'SystemExit',
 'ArithmeticError',
 'AssertionError',
 'AttributeError',
 'BufferError',
 'EOFError',
 'ImportError',
 'LookupError',
 'MemoryError',
 'NameError',
 'OSError',
 'ReferenceError',
 'RuntimeError',
 'StopAsyncIteration',
 'StopIteration',
 'SyntaxError',
 'SystemError',
 'TypeError',
 'ValueError',
 'Warning',
 'FloatingPointError',
 'OverflowError',
 'ZeroDivisionError',
 'BytesWarning',
 'DeprecationWarning',
 'EncodingWarning',
 'FutureWarning',
 'ImportWarning',
 'PendingDeprecationWarning',
 'ResourceWarning',
 'RuntimeWarning',
 'SyntaxWarning',
 'UnicodeWarning',
 'UserWarning',
 'BlockingIOError',
 'ChildProcessError',
 'ConnectionError',
 'FileExistsError',
 'FileNotFoundError',
 'InterruptedError',
 'IsADirectoryError',
 'NotADirectoryError',
 'PermissionError',
 'ProcessLookupError',
 'TimeoutError',
 'IndentationError',
 'IndexError',
 'KeyError',
 'ModuleNotFoundError',
 'NotImplementedError',
 'RecursionError',
 'UnboundLocalError',
 'UnicodeError',
 'BrokenPipeError',
 'ConnectionAbortedError',
 'ConnectionRefusedError',
 'ConnectionResetError',
 'TabError',
 'UnicodeDecodeError',
 'UnicodeEncodeError',
 'UnicodeTranslateError',
 'ExceptionGroup',
 'EnvironmentError',
 'IOError',
 'open',
 'quit',
 'exit',
 'copyright',
 'credits',
 'license',
 'help']


class SafeCodeRuntime(ProtoCodeRuntime, SafeObject):
    result_by_id = {}

    @classmethod
    def get_safe_locals(cls):

        # class MyBuiltIn:
        # class MyBuiltIn(object):

        _dict = dict
        class _dict(dict):
            def __getitem__(self, __k) :
                print(f'getting {__k!r},{type(__k)}')
                v = super().__getitem__(__k)
                print(f'getting {__k!r},{type(__k)}.. done')
                return  v        
        class MyBuiltIn(_dict):
            pass
            # def __getitem__(self,k):
            #     if k not in BUILTIN_ALL:
            #         print('[MyBuiltIn]v1')
            #         raise ValueError(f"Variable {k} is undefined")                
                        
            #     raise NotAllowedError(f'Function not allowed: {k}. Please apply for access with AgentInterface.apply({k!r}), or focus on the AgentInterface.xxx() methods. ')

        def safe_import(name, *a,**kw):
            if name in ["json","re"]:
                mod = __import__(name, *a,**kw)                            
                _locals[name] = mod
                return mod                        
            else:
                raise NotAllowedError(f'Function not allowed: {name}. Please apply for access with AgentInterface.apply({name!r}), or focus on the AgentInterface.xxx() methods. ')


        _locals = _dict(
                dict=dict,
                # breakpoint=breakpoint,
                # Exception = Exception,
                # __builtins__=MyBuiltIn(),
                __builtins__=MyBuiltIn(__import__ = safe_import,**{k:__builtins__[k] for k in BUILTIN_WHITELIST if k in __builtins__}),
                # __builtins__=None,
                AgentInterface = AgentInterface,
                object=object,
                # __import__ = __import__,

        )


        return _locals    
    
    def on_exec_code(self, code, req_id):
                        
        stdout = ''
        success = 0
        exc_str = ''

        def better_compile(src, name, mode):
            # there is an example of this being set at
            # https://hg.python.org/cpython/file/2.7/Lib/linecache.py#l104
            linecache.cache[name] = (
                len(src), None,
                [line+'\n' for line in src.splitlines()], name
            )
            return compile(src, name, mode)    

        _locals = self.get_safe_locals()
        # _locals = {}
        # safe_dict = _locals
        try:
            code_obj = better_compile(code, '<agent-code>', 'exec')    
            _ = exec(code_obj, _locals, _locals)
            stdout = repr(stdout)
        except Exception as e:
            import traceback; 
            exc_str = traceback.format_exc()
        
        return ( code, exc_str, success)
