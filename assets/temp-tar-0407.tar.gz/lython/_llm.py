
from openai import AzureOpenAI, OpenAI
from azure.identity import get_bearer_token_provider, ClientSecretCredential

import os, httpx

import logging
logger = logging.getLogger("risk_feature_explainer")
logger.setLevel(logging.INFO)


# from .base import embedding_func_decorator, BaseKVStorage
# from ._utils import logger, compute_args_hash
embedding_func_decorator = lambda *a,**kw:embedding_func_decorator


global_azure_openai_client = None
global_cosmos_openai_client = None

LLM_CACHE_STORAGE_ARG_NAME = 'llm_cache_kv_storage'

def get_cosmos_openai_client():
    global global_cosmos_openai_client
    if global_cosmos_openai_client is None:
        global_cosmos_openai_client = OpenAI(
            api_key = 'EMPTY',
            base_url = '',
        )
    return global_cosmos_openai_client

def get_cosmos_url(model):
    env = os.getenv('env', 'dev')
    host_url = 'aiplatform.dev51.cbf.dev.paypalinc.com' if env == 'dev' else 'aiplatform.ccg24-hrzana-edk8s.ccg24.lvs.paypalinc.com'
    base_url = f'https://{host_url}/seldon/seldon/{model}/v2/models/{model}'
    return base_url

def get_azure_openai_client():
    global global_azure_openai_client
    if global_azure_openai_client is None:
        tenant_id = os.getenv('AZURE_TENANT_ID')
        client_id = os.getenv('AZURE_CLIENT_ID')
        client_secret = os.getenv('AZURE_CLIENT_SECRET')
        credential = ClientSecretCredential(tenant_id, client_id, client_secret)

        token_provider = get_bearer_token_provider(credential, "https://cognitiveservices.azure.com/.default")

        http_client = httpx.Client(verify=False)

        global_azure_openai_client = AzureOpenAI(
            azure_ad_token_provider=token_provider,
            azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT'),
            api_version = os.getenv('OPENAI_API_VERSION', '2024-10-21'),
            http_client=http_client
        )
    return global_azure_openai_client

def cosmos_openai_complete(
    model, prompt, system_prompt=None, history_messages=[], 
    raw=False,
    **kwargs
) -> str:
    cosmos_openai_client = get_cosmos_openai_client()
    base_url = get_cosmos_url(model)
    cosmos_openai_client.base_url = base_url

    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})
    

    kv_storage: BaseKVStorage = kwargs.pop(LLM_CACHE_STORAGE_ARG_NAME, None)
    if kv_storage is not None:
        args_hash = compute_args_hash(model, messages)
        cache_return = kv_storage.get_by_id(args_hash)
        if cache_return is not None:
            return cache_return

    response = cosmos_openai_client.chat.completions.create(  
        model=model,
        messages=messages,
        **kwargs  
    )

    # logger.debug(f'called cosmos llm api with model: {model}, messages: {messages}, response: {response.choices[0].message.content}')

    if kv_storage is not None:
        kv_storage.upsert({
            args_hash: response.choices[0].message.content
        })
    if raw:
        return response
    return response.choices[0].message.content

def azure_openai_complete(
    model, prompt, system_prompt=None, history_messages=[], **kwargs
) -> str:
    azure_openai_client = get_azure_openai_client()
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})

    kv_storage: BaseKVStorage = kwargs.pop(LLM_CACHE_STORAGE_ARG_NAME, None)
    if kv_storage is not None:
        args_hash = compute_args_hash(model, messages)
        cache_return = kv_storage.get_by_id(args_hash)
        if cache_return is not None:
            return cache_return
    
    response = azure_openai_client.chat.completions.create(  
        model=model,
        messages=messages,
        **kwargs  
    )

    # logger.debug(f'called azure llm api with model: {model}, messages: {messages}, response: {response.choices[0].message.content}')

    if kv_storage is not None:
        kv_storage.upsert({
            args_hash: response.choices[0].message.content
        })

    return response.choices[0].message.content

def azure_openai_complete_2(
    model, prompt, system_prompt=None, history_messages=[], 
    raw=False,
    **kwargs
) -> str:
    azure_openai_client = get_azure_openai_client()
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})

    kv_storage: BaseKVStorage = kwargs.pop(LLM_CACHE_STORAGE_ARG_NAME, None)
    if kv_storage is not None:
        args_hash = compute_args_hash(model, messages)
        cache_return = kv_storage.get_by_id(args_hash)
        if cache_return is not None:
            return cache_return
    
    response = azure_openai_client.chat.completions.create(  
        model=model,
        messages=messages,
        **kwargs  
    )

    logger.debug(f'called azure llm api with model: {model}, messages: {messages}, response: {response.choices[0].message.content}')

    if kv_storage is not None:
        kv_storage.upsert({
            args_hash: response.choices[0].message.content
        })
    if raw:
        return response
    return response.choices[0].message.content



def azure_gpt_4o_mini_complete(
    prompt, system_prompt=None, history_messages=[], **kwargs
) -> str:
    return azure_openai_complete(
        "gpt-4o-mini",
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        temperature=0.1,
        **kwargs,
    )

def azure_gpt_4o_complete(
    prompt, system_prompt=None, history_messages=[], **kwargs
) -> str:
    return azure_openai_complete(
        "gpt-4o",
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        temperature=0.1,
        **kwargs,
    )

def llama3_8b_complete(
    prompt, system_prompt=None, history_messages=[], **kwargs
) -> str:
    env = os.getenv('env', 'dev')
    model = 'llama-3-1-8b-in-0ea04' if env == 'dev' else 'llama-3-8b-inst-b5c1d'
    return cosmos_openai_complete(
        model,
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        **kwargs,
    )

def dpskr1_32b_complete(
    prompt, system_prompt=None, history_messages=[], **kwargs
) -> str:
    env = os.getenv('env', 'dev')
    if env != 'dev':
        raise Exception('deepseek r1 not avaialbe in non-dev env')
    model = 'deepseek-r1-dis-3ad7d'
    return cosmos_openai_complete(
        model,
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        **kwargs,
    )

@embedding_func_decorator(embedding_dim=1536, max_token_size=8192)
def azure_openai_embedding(texts: list[str]) -> list[list[float]]:
    azure_openai_client = get_azure_openai_client()
    response = azure_openai_client.embeddings.create(
        model='text-embedding-3-small',
        input=texts,
        encoding_format='float'
    )
    return [data.embedding for data in response.data]

@embedding_func_decorator(embedding_dim=768, max_token_size=8192)
def cosmos_openai_embedding(texts: list[str]) -> list[list[float]]:
    env = os.getenv('env', 'dev')
    model = 'all-mpnet-base--fccb5' if env == 'dev' else 'all-mpnet-base--4cd30'

    cosmos_openai_client = get_cosmos_openai_client()
    base_url = get_cosmos_url(model)
    cosmos_openai_client.base_url = base_url
    response = cosmos_openai_client.embeddings.create(
        model=model,
        input=texts,
        encoding_format='float'
    )
    return [data.embedding for data in response.data]
