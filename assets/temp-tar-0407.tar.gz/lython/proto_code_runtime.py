import uuid
import json
import multiprocessing
import threading
import linecache
class ProtoCodeRuntime(object):
    is_safe = False ### this runtime is of high code risk  !!!!
    result_by_id = {}
    def get_result(self, req_id, timeout = None):
        '''
        This call is blocking
        '''
        print(f'[{self.__class__.__name__}]get_result({req_id})')
        result = self.result_by_id[req_id].get(timeout=timeout)
        self.result_by_id[req_id].close()
        del self.result_by_id[req_id]
        return json.dumps(result)
    

    def on_recv(self, code):
        '''
        Non-blocking call to put code to execute
        '''
        req_id = uuid.uuid4().hex
        queue = multiprocessing.Queue(maxsize=1)
        self.result_by_id[req_id] = queue
        def func():
            result = self.on_exec_code(code, req_id)
            # print(f '!!![]putting result {result}')
            queue.put(result)
        t = threading.Thread(target=func,)
        t.start()
        return req_id


    def on_exec_code(self, code, req_id):
        # return exec_result_content, success        
        raise NotImplementedError
                        

