import os
os.environ['USE_LANGFUSE'] = '1'


from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
import asyncio
app = FastAPI()

html = """
<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
    </head>
    <body>
        <h1>WebSocket Chat [TBC]!!!!!!</h1>
        <form action="" onsubmit="sendMessage(event)">
            <input type="text" id="messageText" autocomplete="off"/>
            <button>Send</button>
        </form>
        <ul id='messages'>
        </ul>
        <script>
            var ws = new WebSocket("ws://localhost:8000/ws");
            ws.onmessage = function(event) {
                var messages = document.getElementById('messages')
                var message = document.createElement('li')
                var content = document.createTextNode(event.data)
                message.appendChild(content)
                messages.appendChild(message)
            };
            function sendMessage(event) {
                var input = document.getElementById("messageText")
                ws.send(input.value)
                input.value = ''
                event.preventDefault()
            }
        </script>
    </body>
</html>
"""


@app.get("/")
async def get():
    return HTMLResponse(html)

app.web_sockets = []
@app.websocket("/ws/chat")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    Env.web_sockets[websocket]=None
    context = object()
    while True:
        data = await websocket.receive_json()
        print(f'recv: {data}')
        put_resp = await asyncio.to_thread( Env.on_recv, context = context, websocket=websocket, data=data)
        # send_data = await asyncio.to_thread( Env.on_send, context = context,  websocket=websocket, data=data)
        # await websocket.send_json(send_data)
        # print(f'sent: {send_data}')

global Env
import asyncio
import multiprocessing
class BaseEnv(object):
    web_sockets = {}
    data = ''
    send_queue = multiprocessing.Queue()
    @classmethod
    def on_recv(cls, context, websocket, data):
        data = [{"role": "assistant", "content":  'Hi I am bot.'}]
        cls.send_queue.put(data)

    @classmethod
    async def loop_send(cls):
        print('Starting up loop_send')
        while True:
            send_data = await asyncio.to_thread(cls.send_queue.get)
            print('sending data',send_data)
            for websocket in list(cls.web_sockets):
                async def safe_send(websocket=websocket):
                    try:
                        await websocket.send_json(send_data)
                    except Exception as e:
                        if "after sending 'websocket.close'" in repr(e):
                            print(f'Removing disconnected ws {websocket}')
                            cls.web_sockets.pop(websocket,None)
                        else:
                            raise 
                task = safe_send()
                asyncio.get_event_loop().create_task(task)
        return 
        
    @classmethod
    async def on_startup(cls):
        return await asyncio.gather(cls.loop_send())
Env = BaseEnv

@app.on_event("startup")
async def startup_event():
    global Env
    asyncio.get_event_loop().create_task(Env.on_startup())
    


from .agent_notebook_checker import AgentNotebookChecker
from .agent_notebook_checker import AgentInterface
from pprint import pprint

class UserControlMessage(object):
    pass
class UserTaskInitMessage(object):
    pass
# from threading import Que
from multiprocessing import Queue

class AgentNotebookChecker(AgentNotebookChecker, BaseEnv):
    """
    Binding the workflow with a frontend chat interface through web socket
    """
    
    next_msg_type = UserTaskInitMessage
    user_input_queue = Queue(maxsize=1)
    wait_for_input = False

    
    @classmethod
    def on_recv(cls, context, websocket, data):
        ### all messages here are control messages
        content = data['content']
        print('cls.wait_for_input:',cls.wait_for_input)
        if cls.wait_for_input:
            cls.user_input_queue.put(content)
        else:
            print(f'Ignoring Message since not waiting for input {content}')
    
    @classmethod
    def on_send(cls, context, websocket, data):
        return cls.send_queue.get()
    @classmethod
    def broadcast_msg(cls, msg):
        pprint(['sending',msg])
        return cls.send_queue.put([msg])
        
    @classmethod
    @AgentNotebookChecker.observe()
    def get_user_input(self,user_prompt):
        self.wait_for_input = True
        print(f'[{self.__class__.__name__}]UserPrompt:{user_prompt}')
        print('cls.wait_for_input:',self.wait_for_input)
        self.broadcast_msg(dict(role='assistant',content=user_prompt))
        value = self.user_input_queue.get()
        print('self.user_input_queue.get:',value)
        self.wait_for_input = False
        return value
        # return input('Execute Action?: (yES/qUIT/nEXT)').strip()

    @AgentNotebookChecker.observe(capture_output=False)
    def on_append_message(self, msg, add_to_history):
        role = msg['role']
        if role in self.print_channels:
            pprint(msg)
            self.broadcast_msg(msg)
        else:
            print(f'hiding msg from role:{role}')

        if add_to_history:
            self.append_history_message(msg)

        return msg

    @AgentNotebookChecker.observe()
    def init_loop(self,*a,**kw):
        print('Starting workflow loop')
        return super().init_loop(*a,**kw)
    
    @AgentNotebookChecker.observe()
    def run_loop(self,*a,**kw):
        return super().run_loop(*a,**kw)

    @AgentNotebookChecker.observe()
    def on_sample_action(self,*a,**kw):
        # print('Starting workflow loop')
        return super().on_sample_action(*a,**kw)
        # pass


    # @classmethod
    async def on_startup(self):
        workflow = self
        return await asyncio.gather( super().on_startup(), asyncio.to_thread(workflow.run))

import os 
os.environ['AZURE_OPENAI_ENDPOINT'] = 'https://genai-cus-tdz.paypalcorp.com/solar-amps'

os.environ['AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME'] = 'text-embedding-3-large'
os.environ['OPENAI_API_VERSION'] = '2024-10-21'
# os.environ['env'] = 'prod'
os.environ['env'] = 'dev'


import os
 

### macos langfuse
os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-lf-dbe0bb2c-74aa-41a9-b0b6-7ad5dd0526ca"
os.environ["LANGFUSE_SECRET_KEY"] = "sk-lf-1119d2d3-3402-4ad7-b850-66a6002b7079"
os.environ["LANGFUSE_HOST"] = "http://localhost:3000" # 🇪🇺 EU region

### local langfuse
os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-lf-3ad4a2fd-7786-43b4-acc8-82a6d4518934"
os.environ["LANGFUSE_SECRET_KEY"] = "sk-lf-156e4ff0-e402-49f4-a104-37cced43a163"
os.environ["LANGFUSE_HOST"] = "http://localhost:3000" # 🇪🇺 EU region


from ._llm import azure_openai_complete_2
from ._llm import cosmos_openai_complete
import functools



model_name = 'qwen-coder-25-3-e58c2'
def completion_func(self,*a,**kw):
    # return functools.partial(azure_openai_complete_2,model = "gpt-4o-mini",)(*a,**kw)
    # return functools.partial(azure_openai_complete_2,model = "gpt-4o",)(*a,**kw)
    return functools.partial(cosmos_openai_complete,model = self.model_name)(*a,**kw)
    # return functools.partial(cosmos_openai_complete,model = 'deepseek-r1-dis-3ad7d')(*a,**kw)
    # return functools.partial(cosmos_openai_complete,model = 'llama-3-1-8b-in-0ea04')(*a,**kw)
    # partial_caller = functools.partial(cosmos_openai_complete,model = 'llama-3-8b-inst-b5c1d',)
    # partial_caller = functools.partial(azure_openai_complete_2,model = "gpt-4o-mini",)

#### !!!! [external model]: Make sure the data submiitted is in line with the data compliance policy !!!!
# model_name =  "gpt-4o"
# def completion_func(self,*a,**kw):
#     # return functools.partial(azure_openai_complete_2,model = "gpt-4o-mini",)(*a,**kw)
#     return functools.partial(azure_openai_complete_2,model = "gpt-4o",)(*a,**kw)
#     # return functools.partial(cosmos_openai_complete,model = self.model_name)(*a,**kw)
#     # return functools.partial(cosmos_openai_complete,model = 'deepseek-r1-dis-3ad7d')(*a,**kw)
#     # return functools.partial(cosmos_openai_complete,model = 'llama-3-1-8b-in-0ea04')(*a,**kw)
# AgentNotebookChecker.max_context_length = 35*1000

# client = ollama.Client('http://127.0.0.1:18002',)
from openai import OpenAI

client = client = OpenAI(
    base_url = 'http://127.0.0.1:18002/v1',
    api_key='ollama', # required, but unused
)
# model_name = 'qwen2.5-coder:7b'
model_name = 'qwen2.5-coder:14b'
model_name = 'qwen2.5-coder:14b'
model_name = 'qwq:32b'
model_name = 'qwen2.5-coder:32b'
def completion_func(
    self,
    prompt, system_prompt=None, history_messages=[], 
    raw=False,
    **kw
) -> str:

    kw['messages'] = messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})
    # messages=[{'role':'user','content':'今天是星期几？'}]
    return functools.partial(client.chat.completions.create,
                             model = self.model_name)(**kw)

import requests
import json
from openai.resources.chat.completions.completions import ChatCompletion


model_name = "qwen/qwen-2.5-coder-32b-instruct"
openrouter_key = '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'
def completion_func(
    self,
    prompt, system_prompt=None, history_messages=[], 
    raw=False,
    **kw
) -> str:

    kw['messages'] = messages = []
    kw['model'] = self.model_name
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})

    response = requests.post(
    url="https://openrouter.ai/api/v1/chat/completions",
    headers={
        "Authorization": f"Bearer {openrouter_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "<YOUR_SITE_URL>", # Optional. Site URL for rankings on openrouter.ai.
        "X-Title": "<YOUR_SITE_NAME>", # Optional. Site title for rankings on openrouter.ai.
    },
    data=json.dumps(kw),        
    )
    resp = ChatCompletion(**response.json())
    return resp


import os
import litellm
# from litellm import completion
openrouter_key = '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'
os.environ["OPENROUTER_API_KEY"] = openrouter_key
os.environ["OPENROUTER_API_BASE"] = "https://openrouter.ai/api/v1/" # [OPTIONAL] defaults to https://openrouter.ai/api/v1


os.environ["OR_SITE_URL"] = "" # [OPTIONAL]
os.environ["OR_APP_NAME"] = "" # [OPTIONAL]

messages = [dict(role='user',content='hi')]


model_name = "openrouter/qwen/qwen-2.5-coder-32b-instruct"
def completion_func(
    self,
    prompt, system_prompt=None, history_messages=[], 
    raw=False,
    **kw
) -> str:


    kw['messages'] = messages = []
    kw['model'] = self.model_name
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.extend(history_messages)
    messages.append({"role": "user", "content": prompt})

    response = litellm.completion(
                model=self.model_name,
                messages=messages,
            )

    # resp = ChatCompletion(**response.json())
    return response



workflow = AgentNotebookChecker(completion_func,  model_name, 
                                tool_cls_list = [AgentInterface], 
                                # filename="../local_llm/temp.ipynb",
                                filename="./temp.ipynb",
                                )
# AgentInterface._check_target = workflow._check_target
Env = workflow
openrouter_key = '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'
