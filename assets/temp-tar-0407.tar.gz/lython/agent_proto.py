import os,sys
import subprocess
from bs4 import BeautifulSoup

import time

# from openai import AzureOpenAI, OpenAI
# from azure.identity import get_bearer_token_provider, ClientSecretCredential
import functools
from pprint import pformat
import tempfile
import traceback


def wrap_xml_tag(name,content,newline='\n'):
    return f'<{name}>{newline}{content}{newline}</{name}>'

def shell(cmd,shell=True,check=True):
    print(f'Running command: {cmd}')
    ret = subprocess.run(cmd,shell=shell,stderr= subprocess.STDOUT,check=False,stdout=subprocess.PIPE)
    if check:
        assert ret.returncode==0,  f'''Returned nonzero code: {ret.returncode}. STDOUT: {ret.stdout.decode()}'''
    return ret.stdout.decode(),ret

class ContextOverflowError(Exception):
    pass


from .agent_interface import AgentInterface
class AgentPrototype(object):
    print_channels = ['user',
                      'assistant_final',
                      'sys_summary',
                      'error',
                      'assistant',
                      'sys_to_agent','agent_interface'
                      ]    
    max_context_length=30*1000
    def __init__(self, completion_func, model_name, tool_cls_list):
        self.completion_func = completion_func
        self.model_name = model_name
        # tool_cls_list = 
        if AgentInterface not in tool_cls_list:
            tool_cls_list.append(AgentInterface)
        # assert issubclass(tool_cls, AgentInterface), type(tool_cls)
        self.tool_cls_list = tool_cls_list
        self.agent_interface = AgentInterface

    # # @classmethod
    # def bind_tool_cls(cls, tool_cls):
    #     AgentInterface.workflow = workflow

    #     return 
        

    @staticmethod
    def observe(*a,**kw):
        def dec(f):
            return f
        return dec
    USE_LANGFUSE = int(os.environ.get('USE_LANGFUSE','1'))
    if USE_LANGFUSE:
        ### add langfuse tracing
        # from langfuse.decorators import langfuse_context, 
        from langfuse.decorators import observe     

    @staticmethod
    def completion_func(self,*a,**kw) -> 'response':        
        raise NotImplementedError
        return functools.partial(cosmos_openai_complete,model = self.model_name)(*a,**kw)

    @staticmethod
    def get_exec_result(ctx, code):
        raise NotImplementedError

    def prompt_getter(self,):
        raise NotImplementedError

            
    def get_target_text(self):
        raise NotImplementedError
    
    def get_checker_code(self):
        return ''.join(inspect.getsourcelines(self._check_target)[0])        

    def check_target(self,history):        
        exc_str = None
        done = False
        code =  '\n'.join(
                    ['import json'] + 
                    ['class Checker:'] + 
                    self.get_checker_code().splitlines()+
                    [f'Checker._check_target(**json.loads("""{json.dumps(self.kwargs)}"""))'])
        history, new_msg = self.exec_and_send(code, history, keep_result_only=False)
        return history, new_msg
    
    @staticmethod
    def _check_target():
        raise NotImplementedError


    
    def prompt_getter(self,output_cls=None):
        return self._prompt_getter(
            tool_cls_list=self.tool_cls_list, 
            output_cls=output_cls or self.output_cls, 
            target_text=self.get_target_text(),
            model_name=self.model_name,
            )
    
    @staticmethod
    def _prompt_getter(tool_cls_list, output_cls, target_text, model_name='UNKNOWN', output_cls_name=None):
        '''
        Compiling the prompt given input
        '''        
        tool_py_source = ''
        for tool_cls in tool_cls_list:
            with open(inspect.getsourcefile(tool_cls),'r') as f:
                tool_py_source += f.read()
                tool_py_source += '\n'

        output_format_xml = output_cls.to_xml_prompt()

        prompt = f''' 
- Your basic information as a task agent:
    - model_name: {model_name}
- Your target is to
<target>
{target_text}
</target>

- Here is tools avaiable to you. 
<toolCode>
{tool_py_source}
</toolCode>

- Other notes:
    - Please write valid python call wrapped in <code></code> to use tools
    - When you finish thinking, please select one of the tool to continue your work. 
    - Now please start to analyse the situation and write code to learn the situation and reach the target.
    - Make sure to call `AgentInterface.send(content)` to send the output to you!!!

- Please answer in exactly this format  
{output_format_xml}         


            '''.strip()        
        return prompt
        

    def get_exec_result(self, code):  
        req_id = self.code_runtime.on_recv(code)
        ret = json.loads(self.code_runtime.get_result(req_id))
        return ret
        # return exec_result_content, success      
    
    def get_user_input(self,prompt):
        return input(prompt).strip()
    
    def raise_error(self,e,history=tuple()):
        self.append_msg_tuple('error',str(e),history)
        raise e            

    @staticmethod
    def sample_action(workflow, output_cls, history_messages, retry=3, **kwargs):
        self = workflow
        # output_cls = self.output_cls
        output_cls_name = output_cls.__name__
        stop_tag = f'</{output_cls_name}>'
        msg_content = '' 

        for msg in history_messages:
            ### validating the message formats
            assert msg.get('role'),msg
            assert msg.get('content'),msg

        for i in range(retry):

            if repr(history_messages).__len__()>self.max_context_length:
                self.raise_error(ContextOverflowError(f'Exceeded max_context_length={self.max_context_length} '))
            try:
                resp = workflow.completion_func(
                        workflow,
                        prompt='',
                        system_prompt='',
                        history_messages=history_messages,
                        temperature=0.1,
                        n=1,
                        max_tokens=1000,
                        # top_logprobs = 3,
                        # logprobs = True,
                        # logprobs = False,
                        raw=True,
                        stop=[stop_tag,'<|eot_id|>'],
                        # <state-partial>','<state-done>','</code>','<|eot_id|>'],
                        **kwargs,
                    )
                msg = resp.choices[0].message
                ### add back stop_tag since .completion() exclude the last tag
                ### add start_tag if missing
                msg.content += stop_tag
                start_tag = f'<{output_cls_name}>'
                if not msg.content.startswith(start_tag):
                    msg.content = start_tag + msg.content
                msg_content = msg.content


                found = BeautifulSoup(msg_content).findAll(name=output_cls_name)
                if not found:
                    history = workflow.append_output_format_msg(history)
                    raise RuntimeError(f'Unable to parse for tag <{output_cls_name}>')
                agent_message_tag =  found[0]

                ### parsing custom struct
                output_struct     = output_cls.from_message_text(agent_message_tag)
                output_struct.set_raw_msg_tag(agent_message_tag)

                # output_struct = msg_content_parser(msg.content)      
                workflow.last_llm_resp = resp  
                
                new_history =  workflow.append_msg_tuple(msg.role, output_struct.to_msg_storage_str(), history_messages,)
                return output_struct, new_history
            
            except Exception as e:
                workflow.on_append_message({'role':'error','content': msg_content + wrap_xml_tag('error', traceback.format_exc())}, add_to_history = False)
                traceback.print_exc()
                # raise e  ### enable for debugging

        self.raise_error(RuntimeError(f'Unable to generate output after {retry} attempts for context\n...\n{repr(history_messages)[-1000:]}'))
        # assert agent_message is not None,f'Unable to generate output after {retry} attempts'
        # return agent_message
    def append_output_format_msg(self,history):
        '''Ask agent to follow output format'''
        return self.append_msg_tuple('sys_to_agent',
                        f'Note your output should stick to this format {self.output_cls.to_xml_prompt()}',
                        history)

    def on_append_message(self, msg, add_to_history):
        '''
        ### extend this method to capture all messages
        '''
        role = msg['role']
        if role in self.print_channels:
            pprint(msg)
        else:
            print(f'hiding msg from role:{role}')
        if add_to_history:
            assert 0,'method removed'
            # self.append_history_message(msg)
        return msg    
    
    def on_sample_action(self, output_cls, history_messages):
        #   f'[@Agent]: note your output should stick to this format {self.output_cls.to_xml_prompt()}',
        #   add_to_history=True)
        history_messages = tuple(history_messages) ### immutable
        agent_message, new_history_messages = self.sample_action(self, output_cls, history_messages)
        _ = self.append_msg_tuple('sys_summary',f'-----['
                        f'agentSummary:{agent_message.agent_summary},'
                        f'timeElapsed:{(time.time()-self.t0)/60.:.2}min,'
                        f'contextLength:{len(repr(history_messages))}chars]-----',None)
        self.state = agent_message.state
        return agent_message, new_history_messages      

    @staticmethod
    def append_tuple(v, ele):
        '''
        Append an element to the end of tuple
        '''
        assert isinstance(v,tuple),f'{type(v)} is not tuple'
        return v+(ele,)
    
    # @classmethod
    def append_msg_tuple(self,  role, content, history=None, return_msg = False):
        if history is None:
            history = tuple()
        assert isinstance(history, tuple),type(history)

        if role!='assistant':
            ### force the role to be "user" for non-assistant message
            role= 'user'
        msg = {'role':role,'content':content}
        self.on_append_message(msg, add_to_history=False)
        new_history = self.append_tuple(history, msg)
        if not return_msg:
            return new_history
        else:
            return new_history, msg
    
    def append_msg(self, role, content,  add_to_history=True):
        assert add_to_history is False, 'Please manage history messages explicitly!!!'
        msg = {
            'role':role,'content':content,
        }
        self.on_append_message(msg, False)
        return 


    def get_user_input(self,prompt):
        return input(prompt).strip()



    def exec_and_send(workflow,code, history,   keep_result_only):
        exec_code, exc_str, success = workflow.get_exec_result(code)

        buf = ''
        try:
            buf =  workflow.agent_interface.get_safe_buffer()
        except Exception as e:
            print(e)
            pass        
        # finally:
        import io
        workflow.agent_interface.buffer.close()
        workflow.agent_interface.buffer = io.StringIO()

        if keep_result_only:
            exec_code = ''

        exec_result_content = f'''
<CodeExecResult>
<code>
{exec_code}
</code>
<exception>
{exc_str}
</exception>
<AgentInterfaceSend>
{buf}
</AgentInterfaceSend>
</CodeExecResult>
        '''.strip()
        history,new_msg = workflow.append_msg_tuple('sys_to_agent', exec_result_content, history, return_msg= True)
        return history,new_msg
    

import json
from pprint import pprint
import inspect

### types to hint agent
pythonCode = object
thinkingProcessStr = object

import pydantic
from pydantic import Field
from pydantic import BaseModel
# pydantic.BaseModel.model_validate
class LLMOutputBaseModel(BaseModel):
        @classmethod
        def to_prompt(self):
            raise NotImplementedError
            # ###
            # return ''.join(inspect.getsourcelines(self)[0][1:])        

        @classmethod
        def from_message_text(self, tag:"XMLTag"):
            raise NotImplementedError
        
        @classmethod
        def to_xml_prompt(self, output_cls_name=None):
            output_cls_name = output_cls_name or self.__name__
            # return '\n```\n'+wrap_xml_tag(output_cls_name, self.to_prompt()) + '\n```\n'
            return wrap_xml_tag(output_cls_name, self.to_prompt())
        
        def set_raw_msg_tag(self, tag):
            self._raw_msg_tag = tag
        def get_raw_msg_tag(self):
            return self._raw_msg_tag

        def to_msg_storage_str(self):
            return self.get_raw_msg_tag().decode_contents() 
        
class LLMJsonBaseModel(LLMOutputBaseModel):
        # @classmethod
        # def to_prompt(self):
        #     return ''.join(inspect.getsourcelines(self)[0][1:])        

        @classmethod
        def to_prompt(self):
            '''
            Convert class to a template text suitable for LLM
            '''
            buf = ''
            buf+='{'
            buf+='\n'
            for i,(k,v) in enumerate(self.model_fields.items()):
                if i+1!=len(self.model_fields):
                    buf+=(f"\t\"{k}\": ... ,  # type:{v.annotation.__name__} Target: {v.description}")
                else:
                    buf+=(f"\t\"{k}\": ...    # type:{v.annotation.__name__} Target: {v.description}")
                buf+='\n'
            buf+='}'
            return buf
        
        @classmethod
        def from_message_text(self,tag:"XMLTag"):
            return self.model_validate_json(tag.text)
        
                


class LLMXMLBaseModel(LLMOutputBaseModel):
        @classmethod
        def to_prompt(self):
            '''
            Convert class to a template text suitable for LLM
            '''
            buf = ''
            for i,(k,v) in enumerate(self.model_fields.items()):
                buf+= wrap_xml_tag(k, "...",newline='') 
                buf+='\n'
                if v.description:
                    # buf+= f"<!-- {v.description} --> "
                    # buf+= f"# {v.description} --> "
                    for line in v.description.splitlines():
                        buf+= f"# {line}"
                        buf+='\n'
                    # if i+1!= len(self.model_fields):
                buf+='\n'
            buf += '# In your output, please exclude all contents prefixed by #'
            buf+='\n'
            return buf
        
        @classmethod
        def from_message_text(cls,tag:"XMLTag"):
            xdict = {}
            for child in tag.children:
                if child.name:
                    xdict[child.name] = child.text
            return cls(**xdict)
        

        # .content

        
