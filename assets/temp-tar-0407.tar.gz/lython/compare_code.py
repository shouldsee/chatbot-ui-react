

script1 = open('lython/test_script1.py','r').read()

script2 = open('lython/test_script2.py','r').read()

'''Hi please find on which lines there is a difference between scirpt1.py and script2.py'''

code1 = [f'line{lineno}:{x}' for lineno,x in enumerate(script1.splitlines())]
code1 = '\n'.join(code1)
code2 = [f'line{lineno}:{x}' for lineno,x in enumerate(script2.splitlines())]
code2 = '\n'.join(code2)

lines = []
lines1 = script1.splitlines()
lines2 = script2.splitlines()
for i in range(max(len(lines1),len(lines2))):
    # l1 = '<EOF>'
    if i+1<=len(lines1):
        l1 = lines1[i]
        lines.append(f'script1.py:line{i}:{l1}')
    # l2 = '<EOF>'
    if i+1<=len(lines2):
        l2 = lines2[i]
        lines.append(f'script2.py:line{i}:{l2}')
val = '\n'.join(lines)    

prompt = f'''
Hi please summarize the difference between script1.py and script2.py, including the lineno of relevant diff, given the line-by-line info 
Please merge differences if they are next to each other.

script1.py
```
{code1}
```

script2.py
```
{code2}
```

Hi please summarize the difference between script1.py and script2.py, including the lineno of relevant diff, given the line-by-line info 
Please merge differences if they are next to each other. Please report each difference answer in the following format

### Diff 001  
  <file>script1:lineXXX-lineYYY</file>
  <file>script2:lineXXX-lineYYY</file>
  <summary>... some discription of the difference</summary>

# Once finished, print <finished>
'''


prompt = f'''
Hi please summarize the difference between script1.py and script2.py, including the lineno of relevant diff.
Please merge differences if they are next to each other.

{val}

Hi please summarize the difference between script1.py and script2.py, including the lineno of relevant diff, given the line-by-line info 
Please merge differences if they are next to each other. Please report each difference answer in the following format

### Diff 001  
  <file>script1:lineXXX-lineYYY</file>
  <file>script2:lineXXX-lineYYY</file>
  <summary>... some discription of the difference</summary>
  
Once finished, print <finished>
# '''

print(prompt)
